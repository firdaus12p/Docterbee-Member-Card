<?php
// Konfigurasi Database yang Aman dengan Environment Detection
// File ini akan otomatis mendeteksi environment (development/production)

// Load environment detector
return require_once __DIR__ . '/environment.php';
?>
