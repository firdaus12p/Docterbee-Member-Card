**Aturan Jangan Pernah Melanggar**
- Periksa semua codebase dan cari masalahnya sesuai yang di prompt.
- Jangan Pernah Membuat File Debugging, Testing, File_new, file_fix, dll. Tapi perbaiki semua code base yang sudah ada.
- Lakukan apa yang saya promptkan saja, jangan mengganggu fitur lain, dan css lain.
- Periksa semua codebase untuk mencari masalahnya di mana.
- Selalu gunakan bahasa indonesia.
- Saya tidak menggunakan xamp, tapi saya menggunakan phpmyadmin, yang langung dari database hostingan, dan ketika ada perubahan, untuk mengeceknya, saya harus hosting dlu. Jadi tidak usah menjalankan apapun.
- Selalu berikan komentar di setiap code agar saya tau codenya.
- Pastikan sekali lagi, apakah ada yang perlu di ubah lagi agar apa yang di promptkan sudah sesuai.